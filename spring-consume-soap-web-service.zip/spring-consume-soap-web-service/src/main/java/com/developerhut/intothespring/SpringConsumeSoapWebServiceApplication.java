package com.developerhut.intothespring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringConsumeSoapWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringConsumeSoapWebServiceApplication.class, args);
	}

}
