package com.developerhut.intothespring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringConsumeSoapWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
